# 🛍️ Popmart Scraper

Scrape product data và ảnh từ `popmart.com` và `popmart.com/vn` bằng Node.js + Playwright.

## ✅ Features

- Lấy data sản phẩm: tên, giá, SKU, mô tả, category, series
- Tải ảnh về máy (full resolution)
- Export ra **JSON** + **CSV**
- Hỗ trợ cả `popmart.com/us` và `popmart.com/vn`
- Anti-bot evasion (fake user-agent, human-like scrolling)
- API interception (nhanh hơn DOM scraping nếu bắt được API)

## 🚀 Cài đặt

```bash
# 1. Cài Node packages
npm install

# 2. Cài Playwright browsers (bắt buộc, ~200MB)
npx playwright install chromium
```

## ▶️ Chạy

```bash
# Scrape cả 2 sites (mặc định)
npm start

# Chỉ scrape popmart.com/us
npm run scrape:global

# Chỉ scrape popmart.com/vn
npm run scrape:vn

# Giới hạn 50 sản phẩm
node src/index.js --max=50

# Không tải ảnh
node src/index.js --no-images

# Xem browser (không headless, để debug)
# Sửa headless: false trong src/config.js
```

## 📁 Output

```
output/
├── products.json       ← Toàn bộ data (JSON)
├── products.csv        ← Toàn bộ data (CSV, mở bằng Excel)
└── images/
    ├── global/
    │   ├── Labubu_THE_MONSTERS/
    │   │   ├── image_1.jpg
    │   │   └── image_2.jpg
    │   └── ...
    └── vn/
        └── ...
```

## 📦 Cấu trúc JSON

```json
[
  {
    "id": "12345",
    "title": "Labubu THE MONSTERS Series",
    "price": "149,000đ",
    "originalPrice": "",
    "currency": "VND",
    "category": "Blind Box",
    "series": "THE MONSTERS",
    "sku": "POP-XXX",
    "brand": "Pop Mart",
    "inStock": true,
    "images": [
      "https://cdn.popmart.com/.../image1.jpg"
    ],
    "localImages": [
      "./output/images/vn/Labubu.../image_1.jpg"
    ],
    "url": "https://www.popmart.com/vn/products/...",
    "description": "...",
    "site": "vn",
    "scrapedAt": "2026-05-07T..."
  }
]
```

## ⚙️ Tuỳ chỉnh

Sửa file `src/config.js`:

| Setting | Mặc định | Mô tả |
|---------|----------|-------|
| `maxPages` | 10 | Số trang tối đa mỗi site |
| `maxProducts` | 200 | Số sản phẩm tối đa (0 = không giới hạn) |
| `concurrentDownloads` | 5 | Tải ảnh song song |
| `delayBetweenPages` | 2000ms | Delay giữa các trang |
| `headless` | true | Ẩn browser |

## ⚠️ Lưu ý

- Popmart có **anti-bot** — nếu bị block, thử:
  1. Tăng `delayBetweenPages` lên 3000-5000ms
  2. Đặt `headless: false` để xem browser
  3. Dùng proxy (thêm vào `launchBrowser()` trong `src/browser.js`)
- Chỉ dùng cho mục đích **cá nhân / nghiên cứu**
- Không scrape quá nhiều request/giây để tránh ảnh hưởng server

## 🔧 Nếu selectors bị lỗi

Mở browser DevTools trên popmart.com, inspect element sản phẩm, cập nhật CSS selectors trong `src/config.js`.
