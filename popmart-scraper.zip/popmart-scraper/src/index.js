// index.js — Popmart Scraper Entry Point
// Usage:
//   node src/index.js                  → scrape both sites
//   node src/index.js --site=global    → popmart.com/us only
//   node src/index.js --site=vn       → popmart.com/vn only
//   node src/index.js --no-images     → skip image download
//   node src/index.js --max=50        → limit to 50 products

import { launchBrowser } from "./browser.js";
import { scrapeSite } from "./scraper.js";
import { downloadAllImages } from "./downloader.js";
import { exportData } from "./exporter.js";
import { SITES, SCRAPER_CONFIG } from "./config.js";
import fs from "fs-extra";

// Parse CLI args
const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, v] = a.replace("--", "").split("=");
    return [k, v ?? true];
  })
);

// Apply overrides
if (args.max) SCRAPER_CONFIG.maxProducts = parseInt(args.max);
if (args["no-images"]) SCRAPER_CONFIG.downloadImages = false;

const siteFilter = args.site || "all";

async function main() {
  console.log("╔════════════════════════════════════════╗");
  console.log("║      🛍️  POPMART SCRAPER  v1.0.0       ║");
  console.log("╚════════════════════════════════════════╝");
  console.log(`Site    : ${siteFilter}`);
  console.log(`Max     : ${SCRAPER_CONFIG.maxProducts || "unlimited"} products`);
  console.log(`Images  : ${SCRAPER_CONFIG.downloadImages ? "yes" : "no"}`);
  console.log("────────────────────────────────────────");

  await fs.ensureDir(SCRAPER_CONFIG.outputDir);
  await fs.ensureDir(SCRAPER_CONFIG.imagesDir);

  const browser = await launchBrowser();
  const allProducts = [];

  try {
    // Determine which sites to scrape
    const sitesToScrape = [];
    if (siteFilter === "all" || siteFilter === "global") sitesToScrape.push(SITES.global);
    if (siteFilter === "all" || siteFilter === "vn") sitesToScrape.push(SITES.vn);

    for (const site of sitesToScrape) {
      const products = await scrapeSite(browser, site);
      allProducts.push(...products);
      console.log(`\n✅ ${site.name}: ${products.length} products scraped`);
    }
  } finally {
    await browser.close();
  }

  if (allProducts.length === 0) {
    console.log("\n⚠️  No products found. Popmart may have updated their site.");
    console.log("   Try running with --site=global or check the selectors in config.js");
    process.exit(1);
  }

  // Download images
  let finalProducts = allProducts;
  if (SCRAPER_CONFIG.downloadImages) {
    finalProducts = await downloadAllImages(allProducts);
  }

  // Export
  console.log("\n💾 Saving data...");
  await exportData(finalProducts);

  console.log("✅ Done! Check ./output/ for results.");
}

main().catch((err) => {
  console.error("\n❌ Fatal error:", err.message);
  console.error(err.stack);
  process.exit(1);
});
