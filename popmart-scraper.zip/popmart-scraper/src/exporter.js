// exporter.js — Save scraped data to JSON and CSV

import fs from "fs-extra";
import { createObjectCsvWriter } from "csv-writer";
import { SCRAPER_CONFIG } from "./config.js";

export async function exportData(products, outputDir = SCRAPER_CONFIG.outputDir) {
  await fs.ensureDir(outputDir);

  const jsonPath = SCRAPER_CONFIG.dataFile;
  const csvPath = SCRAPER_CONFIG.csvFile;

  // Save JSON
  await fs.writeJson(jsonPath, products, { spaces: 2 });
  console.log(`  💾 JSON saved: ${jsonPath} (${products.length} products)`);

  // Save CSV
  const csvWriter = createObjectCsvWriter({
    path: csvPath,
    header: [
      { id: "id", title: "ID" },
      { id: "title", title: "Title" },
      { id: "price", title: "Price" },
      { id: "originalPrice", title: "Original Price" },
      { id: "currency", title: "Currency" },
      { id: "category", title: "Category" },
      { id: "series", title: "Series" },
      { id: "sku", title: "SKU" },
      { id: "brand", title: "Brand" },
      { id: "inStock", title: "In Stock" },
      { id: "status", title: "Status" },
      { id: "site", title: "Site" },
      { id: "url", title: "URL" },
      { id: "imagesStr", title: "Images" },
      { id: "localImagesStr", title: "Local Images" },
      { id: "description", title: "Description" },
      { id: "scrapedAt", title: "Scraped At" },
    ],
  });

  const csvRows = products.map((p) => ({
    ...p,
    imagesStr: (p.images || []).join(" | "),
    localImagesStr: (p.localImages || []).join(" | "),
    description: (p.description || "").replace(/\n/g, " ").slice(0, 500),
  }));

  await csvWriter.writeRecords(csvRows);
  console.log(`  📊 CSV saved: ${csvPath}`);

  // Print summary
  printSummary(products);
}

function printSummary(products) {
  const bySite = {};
  for (const p of products) {
    const site = p.site || "unknown";
    bySite[site] = (bySite[site] || 0) + 1;
  }

  const withImages = products.filter((p) => p.images?.length > 0).length;
  const withLocalImages = products.filter((p) => p.localImages?.length > 0).length;
  const totalImages = products.reduce((sum, p) => sum + (p.images?.length || 0), 0);

  console.log("\n" + "═".repeat(50));
  console.log("📊 SCRAPE SUMMARY");
  console.log("═".repeat(50));
  console.log(`  Total products : ${products.length}`);
  console.log(`  With images    : ${withImages} (${totalImages} total URLs)`);
  console.log(`  Downloaded     : ${withLocalImages} products`);
  console.log(`  By site:`);
  for (const [site, count] of Object.entries(bySite)) {
    console.log(`    ${site.padEnd(12)} : ${count} products`);
  }
  console.log("═".repeat(50) + "\n");
}
