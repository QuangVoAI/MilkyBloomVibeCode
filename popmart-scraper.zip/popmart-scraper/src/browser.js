// browser.js — Launch Playwright with anti-bot evasion

import { chromium } from "playwright";
import { SCRAPER_CONFIG, BROWSER_HEADERS } from "./config.js";

export async function launchBrowser() {
  const browser = await chromium.launch({
    headless: SCRAPER_CONFIG.headless,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-blink-features=AutomationControlled",
      "--disable-dev-shm-usage",
      "--lang=vi-VN",
    ],
  });
  return browser;
}

export async function createPage(browser) {
  const context = await browser.newContext({
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    extraHTTPHeaders: BROWSER_HEADERS,
    viewport: { width: 1440, height: 900 },
    locale: "vi-VN",
    timezoneId: "Asia/Ho_Chi_Minh",
  });

  const page = await context.newPage();

  // Hide webdriver fingerprint
  await page.addInitScript(() => {
    Object.defineProperty(navigator, "webdriver", { get: () => undefined });
    Object.defineProperty(navigator, "plugins", { get: () => [1, 2, 3] });
    window.chrome = { runtime: {} };
  });

  // Intercept and log API calls (useful for reverse-engineering)
  const apiCalls = [];
  page.on("response", async (response) => {
    const url = response.url();
    if (
      url.includes("/api/") &&
      response.headers()["content-type"]?.includes("json")
    ) {
      try {
        const json = await response.json().catch(() => null);
        if (json) apiCalls.push({ url, data: json });
      } catch {}
    }
  });

  page._apiCalls = apiCalls;
  return page;
}

export async function waitForProducts(page, selector) {
  try {
    await page.waitForSelector(selector, { timeout: 10000 });
    return true;
  } catch {
    return false;
  }
}
