// scraper.js — Extract product data from Popmart pages

import { SCRAPER_CONFIG } from "./config.js";
import { createPage, waitForProducts } from "./browser.js";

/**
 * Scrape all products from a Popmart site config
 */
export async function scrapeSite(browser, siteConfig) {
  const page = await createPage(browser);
  const products = [];
  const seen = new Set();

  console.log(`\n🌐 Scraping: ${siteConfig.name}`);
  console.log(`   URL: ${siteConfig.collectionsUrl}\n`);

  try {
    // Step 1: Try intercepting API calls first (fastest method)
    const apiProducts = await tryApiInterception(page, siteConfig);
    if (apiProducts.length > 0) {
      console.log(`  ✅ Got ${apiProducts.length} products via API interception`);
      return deduplicateProducts(apiProducts);
    }

    // Step 2: Fall back to DOM scraping
    console.log("  ℹ️  API interception empty, falling back to DOM scraping...");
    let pageNum = 1;
    let hasMore = true;
    let currentUrl = siteConfig.collectionsUrl;

    while (hasMore && pageNum <= SCRAPER_CONFIG.maxPages) {
      console.log(`  📄 Page ${pageNum}: ${currentUrl}`);

      await page.goto(currentUrl, {
        waitUntil: "networkidle",
        timeout: SCRAPER_CONFIG.timeout,
      });

      // Random human-like delay
      await page.waitForTimeout(1000 + Math.random() * 1500);

      // Scroll to trigger lazy loading
      await autoScroll(page);

      // Extract products from current page
      const pageProducts = await extractProductsFromPage(page, siteConfig);
      console.log(`     Found ${pageProducts.length} products on page ${pageNum}`);

      for (const product of pageProducts) {
        const key = product.url || product.title;
        if (key && !seen.has(key)) {
          seen.add(key);
          product.site = siteConfig.locale;
          product.currency = siteConfig.currency;
          products.push(product);
        }
      }

      // Check limit
      if (
        SCRAPER_CONFIG.maxProducts > 0 &&
        products.length >= SCRAPER_CONFIG.maxProducts
      ) {
        console.log(`  🛑 Reached max products limit (${SCRAPER_CONFIG.maxProducts})`);
        break;
      }

      // Navigate to next page
      const nextUrl = await getNextPageUrl(page, siteConfig, pageNum);
      if (nextUrl && nextUrl !== currentUrl) {
        currentUrl = nextUrl;
        pageNum++;
        await page.waitForTimeout(SCRAPER_CONFIG.delayBetweenPages);
      } else {
        hasMore = false;
      }
    }

    // Step 3: For each product, get full details
    console.log(`\n  📦 Fetching details for ${Math.min(products.length, 50)} products...`);
    const detailed = await enrichProductDetails(browser, products.slice(0, 50), siteConfig);

    return detailed;
  } finally {
    await page.close();
  }
}

/**
 * Try to intercept Popmart's internal API calls
 */
async function tryApiInterception(page, siteConfig) {
  const captured = [];

  page.on("response", async (response) => {
    const url = response.url();
    const contentType = response.headers()["content-type"] || "";

    if (!contentType.includes("json")) return;

    // Match Popmart API patterns
    if (
      url.includes("/api/") &&
      (url.includes("product") || url.includes("item") || url.includes("goods"))
    ) {
      try {
        const json = await response.json();
        const items = extractFromApiResponse(json);
        captured.push(...items);
      } catch {}
    }
  });

  // Visit the page to trigger API calls
  await page.goto(siteConfig.collectionsUrl, {
    waitUntil: "networkidle",
    timeout: SCRAPER_CONFIG.timeout,
  });
  await autoScroll(page);
  await page.waitForTimeout(3000);

  return captured.map((p) => ({ ...p, site: siteConfig.locale, currency: siteConfig.currency }));
}

/**
 * Try to parse common API response shapes
 */
function extractFromApiResponse(json) {
  // Try common response shapes
  const candidates = [
    json?.data?.list,
    json?.data?.items,
    json?.data?.products,
    json?.result?.list,
    json?.list,
    json?.items,
    json?.products,
    Array.isArray(json) ? json : null,
  ];

  for (const list of candidates) {
    if (Array.isArray(list) && list.length > 0 && list[0]?.name) {
      return list.map(normalizeApiProduct);
    }
  }
  return [];
}

function normalizeApiProduct(item) {
  return {
    id: item.id || item.productId || item.goodsId || "",
    title: item.name || item.title || item.productName || "",
    price: item.price || item.salePrice || item.minPrice || "",
    originalPrice: item.originalPrice || item.marketPrice || "",
    category: item.categoryName || item.category || "",
    series: item.seriesName || item.series || "",
    sku: item.sku || item.skuCode || "",
    status: item.status || item.stockStatus || "",
    images: extractImages(item),
    url: item.productUrl || item.url || item.detailUrl || "",
    description: item.description || item.intro || "",
    tags: item.tags || [],
    scrapedAt: new Date().toISOString(),
  };
}

function extractImages(item) {
  const imgs = [];
  if (item.coverImg) imgs.push(item.coverImg);
  if (item.image) imgs.push(item.image);
  if (item.mainImage) imgs.push(item.mainImage);
  if (Array.isArray(item.images)) imgs.push(...item.images.map((i) => i?.url || i));
  if (Array.isArray(item.imgList)) imgs.push(...item.imgList);
  return [...new Set(imgs.filter(Boolean))];
}

/**
 * Extract products from DOM
 */
async function extractProductsFromPage(page, siteConfig) {
  return await page.evaluate((baseUrl) => {
    const products = [];

    // Find all product links
    const links = Array.from(document.querySelectorAll("a[href*='/products/']"));
    const seen = new Set();

    for (const link of links) {
      const href = link.getAttribute("href") || "";
      if (seen.has(href)) continue;
      seen.add(href);

      // Walk up to find the product card container
      let card = link;
      for (let i = 0; i < 5; i++) {
        if (card.parentElement) card = card.parentElement;
        if (card.querySelector("img") && card.querySelector("[class*='price'], [class*='Price']")) {
          break;
        }
      }

      const titleEl =
        card.querySelector("[class*='title'], [class*='Title'], [class*='name'], [class*='Name'], h3, h2") ||
        link.querySelector("span, div");
      const priceEl = card.querySelector("[class*='price'], [class*='Price']");
      const imgEl = card.querySelector("img");

      const fullUrl = href.startsWith("http") ? href : baseUrl + href;

      products.push({
        title: titleEl?.textContent?.trim() || link.textContent?.trim() || "",
        price: priceEl?.textContent?.trim() || "",
        images: imgEl?.src ? [imgEl.src] : [],
        url: fullUrl,
        scrapedAt: new Date().toISOString(),
      });
    }

    return products;
  }, siteConfig.baseUrl);
}

/**
 * Get details from individual product page
 */
async function enrichProductDetails(browser, products, siteConfig) {
  const enriched = [];

  for (let i = 0; i < products.length; i++) {
    const product = products[i];
    if (!product.url) {
      enriched.push(product);
      continue;
    }

    process.stdout.write(`\r  🔍 Details: ${i + 1}/${products.length} — ${product.title?.slice(0, 40)}`);

    try {
      const page = await createPage(browser);
      const details = await scrapeProductDetail(page, product.url, siteConfig);
      await page.close();

      enriched.push({ ...product, ...details });
      await new Promise((r) => setTimeout(r, 1000 + Math.random() * 500));
    } catch (err) {
      enriched.push(product);
    }
  }

  console.log();
  return enriched;
}

async function scrapeProductDetail(page, url, siteConfig) {
  try {
    await page.goto(url, { waitUntil: "networkidle", timeout: SCRAPER_CONFIG.timeout });
    await page.waitForTimeout(1500);

    // Also capture API during detail page load
    const apiData = page._apiCalls?.find((c) => c.url.includes("product"));

    return await page.evaluate(() => {
      // Extract all images from the gallery
      const imgEls = Array.from(
        document.querySelectorAll(
          "[class*='gallery'] img, [class*='swiper'] img, [class*='carousel'] img, [class*='detail'] img"
        )
      );
      const images = [...new Set(imgEls.map((img) => img.src || img.dataset.src).filter(Boolean))];

      // Description / intro text
      const descEl = document.querySelector(
        "[class*='description'], [class*='intro'], [class*='detail-text'], [class*='content']"
      );

      // Try to get structured data from JSON-LD
      const jsonLd = document.querySelector('script[type="application/ld+json"]');
      let structured = {};
      if (jsonLd) {
        try {
          structured = JSON.parse(jsonLd.textContent);
        } catch {}
      }

      // Price elements
      const prices = Array.from(document.querySelectorAll("[class*='price'], [class*='Price']"))
        .map((el) => el.textContent.trim())
        .filter((t) => t && /[\d,.]+/.test(t));

      return {
        images: images.slice(0, 20),
        description: descEl?.textContent?.trim() || structured.description || "",
        price: prices[0] || structured.offers?.price || "",
        originalPrice: prices[1] || "",
        sku: structured.sku || structured.mpn || "",
        brand: structured.brand?.name || "Pop Mart",
        inStock: !document.querySelector("[class*='sold-out'], [class*='soldOut']"),
      };
    });
  } catch {
    return {};
  }
}

async function getNextPageUrl(page, siteConfig, currentPage) {
  try {
    return await page.evaluate((currentPage) => {
      // Try numbered pagination
      const nextLink = document.querySelector(
        `a[href*="page=${currentPage + 1}"], ` +
        `a[aria-label="Next"], ` +
        `[class*='pagination'] a:last-child`
      );
      if (nextLink?.href) return nextLink.href;

      // Try URL pattern
      const url = new URL(window.location.href);
      url.searchParams.set("page", currentPage + 1);
      return url.toString();
    }, currentPage);
  } catch {
    return null;
  }
}

async function autoScroll(page) {
  await page.evaluate(async () => {
    await new Promise((resolve) => {
      let totalHeight = 0;
      const distance = 300;
      const timer = setInterval(() => {
        window.scrollBy(0, distance);
        totalHeight += distance;
        if (totalHeight >= document.body.scrollHeight - window.innerHeight) {
          clearInterval(timer);
          resolve();
        }
      }, 100);
    });
  });
}

function deduplicateProducts(products) {
  const seen = new Set();
  return products.filter((p) => {
    const key = p.id || p.url || p.title;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
