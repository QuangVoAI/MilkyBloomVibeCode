// downloader.js — Download product images with concurrency control

import axios from "axios";
import fs from "fs-extra";
import path from "path";
import { SCRAPER_CONFIG } from "./config.js";

/**
 * Download all images for a list of products
 * Returns updated products with local image paths
 */
export async function downloadAllImages(products, outputDir = SCRAPER_CONFIG.imagesDir) {
  await fs.ensureDir(outputDir);

  console.log(`\n📸 Downloading images to: ${outputDir}`);
  console.log(`   Concurrent downloads: ${SCRAPER_CONFIG.concurrentDownloads}\n`);

  // Build a flat list of download tasks
  const tasks = [];
  for (const product of products) {
    const safeName = sanitizeFilename(product.title || product.id || "product");
    const productDir = path.join(outputDir, product.site || "global", safeName);

    for (let i = 0; i < (product.images || []).length; i++) {
      const imgUrl = product.images[i];
      if (!imgUrl || !imgUrl.startsWith("http")) continue;

      tasks.push({
        product,
        imgUrl: cleanImageUrl(imgUrl),
        localPath: path.join(productDir, `image_${i + 1}${getExtension(imgUrl)}`),
        productDir,
        index: i,
      });
    }
  }

  console.log(`   Total images to download: ${tasks.length}`);

  // Download in batches
  const results = [];
  for (let i = 0; i < tasks.length; i += SCRAPER_CONFIG.concurrentDownloads) {
    const batch = tasks.slice(i, i + SCRAPER_CONFIG.concurrentDownloads);
    const batchResults = await Promise.allSettled(batch.map(downloadImage));

    for (let j = 0; j < batch.length; j++) {
      const result = batchResults[j];
      const task = batch[j];
      if (result.status === "fulfilled" && result.value) {
        results.push({ task, localPath: result.value });
        process.stdout.write(`\r  ✅ ${i + j + 1}/${tasks.length} downloaded`);
      } else {
        results.push({ task, localPath: null });
        process.stdout.write(`\r  ❌ ${i + j + 1}/${tasks.length} failed`);
      }
    }
  }

  console.log("\n");

  // Update products with local paths
  const productImageMap = {};
  for (const { task, localPath } of results) {
    const key = task.product.url || task.product.title;
    if (!productImageMap[key]) productImageMap[key] = [];
    if (localPath) productImageMap[key].push(localPath);
  }

  return products.map((product) => {
    const key = product.url || product.title;
    return {
      ...product,
      localImages: productImageMap[key] || [],
    };
  });
}

async function downloadImage({ imgUrl, localPath, productDir }) {
  await fs.ensureDir(productDir);

  // Skip if already downloaded
  if (await fs.pathExists(localPath)) return localPath;

  const response = await axios.get(imgUrl, {
    responseType: "arraybuffer",
    timeout: 15000,
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      Referer: "https://www.popmart.com/",
    },
    maxRedirects: 5,
  });

  await fs.writeFile(localPath, response.data);
  return localPath;
}

function cleanImageUrl(url) {
  // Remove query params that force low resolution
  try {
    const u = new URL(url);
    // Keep only essential params, remove resize/quality params
    ["w", "h", "width", "height", "quality", "q", "resize", "format"].forEach(
      (p) => u.searchParams.delete(p)
    );
    return u.toString();
  } catch {
    return url;
  }
}

function getExtension(url) {
  const match = url.match(/\.(jpg|jpeg|png|webp|gif|avif)(\?|$)/i);
  return match ? `.${match[1].toLowerCase()}` : ".jpg";
}

function sanitizeFilename(name) {
  return name
    .replace(/[^a-zA-Z0-9\-_\u00C0-\u024F\u4E00-\u9FFF]/g, "_")
    .replace(/_+/g, "_")
    .slice(0, 80);
}
