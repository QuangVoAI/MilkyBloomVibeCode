// config.js — Site configs & selectors for popmart.com and popmart.com/vn

export const SITES = {
  global: {
    name: "Popmart Global",
    baseUrl: "https://www.popmart.com",
    collectionsUrl: "https://www.popmart.com/us/collections/all",
    newArrivalsUrl: "https://www.popmart.com/us/new-arrivals",
    locale: "us",
    currency: "USD",
    // CSS selectors (update if site changes)
    selectors: {
      productCard: "div[class*='productCard'], div[class*='product-card'], li[class*='product']",
      productTitle: "[class*='title'], [class*='name'], h3, h2",
      productPrice: "[class*='price']",
      productImage: "img[class*='product'], img[class*='cover'], .product-image img",
      productLink: "a[href*='/products/']",
      nextPage: "a[aria-label='Next'], button[class*='next'], [class*='pagination'] a:last-child",
      loadMore: "button[class*='load-more'], button[class*='loadMore']",
    },
    // Known API endpoints (reverse-engineered from browser network tab)
    apiEndpoints: {
      products: "https://www.popmart.com/api/v1/us/products",
      collections: "https://www.popmart.com/api/v1/us/collections",
    },
  },

  vn: {
    name: "Popmart Vietnam",
    baseUrl: "https://www.popmart.com",
    collectionsUrl: "https://www.popmart.com/vn/collections/all",
    newArrivalsUrl: "https://www.popmart.com/vn/new-arrivals",
    locale: "vn",
    currency: "VND",
    selectors: {
      productCard: "div[class*='productCard'], div[class*='product-card'], li[class*='product']",
      productTitle: "[class*='title'], [class*='name'], h3, h2",
      productPrice: "[class*='price']",
      productImage: "img[class*='product'], img[class*='cover'], .product-image img",
      productLink: "a[href*='/products/']",
      nextPage: "a[aria-label='Next'], button[class*='next'], [class*='pagination'] a:last-child",
      loadMore: "button[class*='load-more'], button[class*='loadMore']",
    },
    apiEndpoints: {
      products: "https://www.popmart.com/api/v1/vn/products",
      collections: "https://www.popmart.com/api/v1/vn/collections",
    },
  },
};

export const SCRAPER_CONFIG = {
  maxPages: 10,           // Max product listing pages per site
  maxProducts: 200,       // Max products to scrape (0 = unlimited)
  downloadImages: true,   // Download images locally
  imageFormat: "original", // 'original' | 'webp' | 'jpg'
  concurrentDownloads: 5, // Parallel image downloads
  delayBetweenPages: 2000,// ms delay between pages (be polite!)
  headless: true,         // Run browser headless
  timeout: 30000,         // Page load timeout

  // Output
  outputDir: "./output",
  imagesDir: "./output/images",
  dataFile: "./output/products.json",
  csvFile: "./output/products.csv",
};

// Browser headers to appear human
export const BROWSER_HEADERS = {
  "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
};
